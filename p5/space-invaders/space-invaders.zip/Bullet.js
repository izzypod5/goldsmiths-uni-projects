"use strict"; 
class Bullet {
  constructor(init_x, init_y){
    this.size = {
      x:10,
      y:10
    };    
    this.position = {
      x:init_x,
      y:init_y
    };
    this.speed = 15;//15
  }
  
  //display bullets based on if going forward or backward direction
  display(dir){
    this.position.y += dir * this.speed;
    fill("white");
    ellipse(this.position.x, this.position.y, this.size.x, this.size.y);
  }
  
  //can hit an enemy or wall
  hits(object){
    var distance = dist(this.position.x , this.position.y, object.position.x + (object.size.x/2), object.position.y + (object.size.y/2));
    //checking the bullet distance from object is less than 
    //the sum of the radius of the object and bullet
    if(distance < (this.size.x /2) + (object.size.x/2)){
      return true;
    }
    return false;
  }
}