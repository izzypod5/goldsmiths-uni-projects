"use strict";
class GameObject {
  constructor(lives, position) {
      this.lives = lives;
      this.position = position;
  }
  
  display() {}
}