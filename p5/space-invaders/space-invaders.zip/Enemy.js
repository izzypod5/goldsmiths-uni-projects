"use strict";
class Enemy {
  constructor(score, init_x, init_y, size_x, size_y){
    this.score = score;    
    this.size = {
      x:size_x,
      y:size_y//20
    };    
    this.position = {
      x:init_x,
      y:init_y
    };
    this.bulletSound = sounds.invaderBullet;
    this.hitSound = sounds.invaderHit;
  }
  
  //display
  display(){
    fill("white");
    rect(this.position.x, this.position.y, this.size.x, this.size.y);
  }
}