var player, colony;//, bunkers = [];
var blockSize = 24, xBunkerSize = blockSize * 4;
      //using width to align bunkers with equal spacing there's 4 walls
var totalBunkerSpacing, currentX, bunkers;
    
function preload() {
    //loading sounds
    sounds = {
        "invaderBullet" : loadSound('sounds/InvaderBullet.wav'),
        "invaderHit" : loadSound('sounds/InvaderHit.wav'),
        "playerBullet" : loadSound('sounds/ShipBullet.wav'),
        "playerHit" : loadSound('sounds/ShipHit.wav')
    };
    images = {
      "invaderA" : {
        "image1" : loadImage('images/InvaderA_00.png'),
        "image2" : loadImage('images/InvaderA_01.png')        
      },
      "invaderB" : {
        "image1" : loadImage('images/InvaderB_00.png'),
        "image2" : loadImage('images/InvaderB_01.png')        
      },
      "invaderC" : {
        "image1" : loadImage('images/InvaderC_00.png'),
        "image2" : loadImage('images/InvaderC_01.png')        
      },
      "UFO" : loadImage('images/UFO.png')
    };
}

function setup() {
    frameRate(30);
    //prevents high density
    createCanvas(800, 800);
    player = new Player();
    colony = new Colony();
    
    //using width to align bunkers with equal spacing there's 4 walls
    totalBunkerSpacing = (width - 4*xBunkerSize) / 5;
    currentX = totalBunkerSpacing;
    bunkers = new Bunkers(height-250);
    bunkers.init();
    //initialises enemies
    colony.init();
}

function draw() {
  designCanvas();
  displayObjects();
}

function keyPressed(){  
  //checking for start of movement
  if(keyCode == LEFT_ARROW || keyCode == RIGHT_ARROW || keyCode == 32){ 
    player.keyEvents[keyCode] = true;
  }
}

function keyReleased(){
  //checking for end of movement
  //left, right, space
  if(keyCode == LEFT_ARROW || keyCode == RIGHT_ARROW || keyCode == 32){    
    player.keyEvents[keyCode] = false;
  }
}

//bitwise, exceptions, polymorphism, inheritance, memory management


// .something = () => {}